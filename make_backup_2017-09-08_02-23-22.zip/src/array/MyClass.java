package array;

public class MyClass {
    public void print() {
        System.out.println("This is a dummy Class");

    }
}