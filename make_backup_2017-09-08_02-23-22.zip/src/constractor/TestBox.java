package constractor;

public class TestBox {
	public static void main(String[]args){
		Box obj = new Box();
		//obj.length = 1;
		obj.area();

	}
}
