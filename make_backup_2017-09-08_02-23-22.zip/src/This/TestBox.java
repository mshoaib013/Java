package This;

public class TestBox {
	public static void main(String[]args){
		Box obj = new Box();
		obj.boxWidth = 30;
		obj.boxLength = 30;
		obj.boxArea(10);
	}
}
