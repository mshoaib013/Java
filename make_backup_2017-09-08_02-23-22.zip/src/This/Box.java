package This;

public class Box {
	int boxLength;
	int boxWidth;

	void boxArea(int boxLength){
		int boxArea = boxLength * boxWidth;
		System.out.println(boxArea);
	}
}
