package method;

public class employee {
    int salary,bonus;
    int totalSal(){
        int a;
        a=salary+bonus;
        return a;
    }
}
