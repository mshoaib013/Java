package Overriding;

public class TestBox {
	public static  void main(){
		NewBox obj = new NewBox();
		obj.area(5,6);
	}
}
