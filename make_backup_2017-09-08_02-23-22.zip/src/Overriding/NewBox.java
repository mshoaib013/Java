package Overriding;

public class NewBox {
	
	void area(int width, int length){
		int area = width*length;
		System.out.println("Fired from Sub Class & Area is : " + area);
	}
}
